let Game = Parse.Object.extend('Game')

export {Game}
