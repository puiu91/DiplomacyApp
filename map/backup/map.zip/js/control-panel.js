// add click listeners on all modify unit order buttons
var modifyOrderButtons = document.querySelectorAll('[data-button = modify]')
var i = 0

for (i = modifyOrderButtons.length; i--;) {

    (function(i) {

        modifyOrderButtons[i].addEventListener('click', function(event) {  

            /**
             * table cells of row that clicked button belongs to
             * @type {HTMLCollection}
             */
            var rowData = this.parentNode.parentNode.children

            /**
             * store information about unit
             * @type {Object}
             */
            var unit = {
                'type' : rowData[0].textContent,
                'province' : rowData[1].textContent,
                'status' : rowData[2].textContent
            }

            // display modal
            var modal = document.getElementById('createUnitModal')
            modal.classList.toggle('visible')

            // todo: block out rest of window to prevent clicking            





            debug(unit)
        });

    })(i);
};

debug(modifyOrderButtons)